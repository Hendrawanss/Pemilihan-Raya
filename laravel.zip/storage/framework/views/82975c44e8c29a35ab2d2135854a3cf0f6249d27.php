<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th>Progam Studi</th>
                    <th>Jurusan</th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $mhs_mesin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($mhs -> nim); ?></td>
                    <td><?php echo e($mhs -> nama_mhs); ?></td>
                    <td><?php echo e($mhs -> kelas); ?></td>
                    <td><?php echo e($mhs -> prodi); ?></td>
                    <td><?php echo e($mhs -> nama_jurusan); ?></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>