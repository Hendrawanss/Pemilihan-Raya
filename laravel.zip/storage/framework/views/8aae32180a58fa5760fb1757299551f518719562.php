<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>Nomor Urut</th>
                    <th>Presma</th>
                    <th>Wapresma</th>
                    <th>Foto Presma</th>
                    <th>Foto Wapresma</th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $presma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($presma -> no); ?></td>
                    <td><?php echo e($presma -> urutan); ?></td>
                    <td><?php echo e($presma -> presma); ?></td>
                    <td><?php echo e($presma -> wapresma); ?></td>
                    <td><?php echo e($presma -> foto_presma); ?></td>
                    <td><?php echo e($presma -> foto_wapresma); ?></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>