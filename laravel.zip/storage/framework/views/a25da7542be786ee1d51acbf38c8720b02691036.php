<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>Nomor Urut</th>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Jurusan</th>
                    <th>Foto BPM</th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $bpm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bpm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($bpm -> no); ?></td>
                    <td><?php echo e($bpm -> urutan); ?></td>
                    <td><?php echo e($bpm -> nim); ?></td>
                    <td><?php echo e($bpm -> nama_mhs); ?></td>
                    <td><?php echo e($bpm -> nama_jurusan); ?></td>
                    <td><?php echo e($bpm -> foto); ?></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>